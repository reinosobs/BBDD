package es.urjc.etsii.dad.ContactoCero;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Rutinas {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String rutina;
	private char dificultad;
	
	@OneToMany(mappedBy= "rutinas")
	private static ArrayList<Usuario> i_Usuario;
	
	
	@ManyToMany(mappedBy="rutinas")
	private List<Ejercicios> ejercicios;
	
	protected Rutinas() {}
	
	/*public Rutinas(String rutina, char dificultad) {
		this.rutina=rutina;
		this.dificultad=dificultad;
	}*/

	public String getRutina() {
		return rutina;
	}

	public char getDificultad() {
		return dificultad;
	}

	public List<Ejercicios> getEjercicios() {
		return ejercicios;
	}

	@Override
	public String toString() {
		return "Rutina [rutina=" + rutina + ", dificultad=" + dificultad + ", ejercicios=" + ejercicios + "]";
	}
	
	

}
