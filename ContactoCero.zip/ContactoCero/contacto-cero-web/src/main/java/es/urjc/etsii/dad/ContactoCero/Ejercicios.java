package es.urjc.etsii.dad.ContactoCero;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Ejercicios {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String nombre;
	private String musculo;
	
	@ManyToMany
	private List<Rutinas> rutinas;
	
	protected Ejercicios() {}
	
	/*public Ejercicios(String nombre, String musculo) {
		this.nombre=nombre;
		this.musculo=musculo;
	}*/

	public String getNombre() {
		return nombre;
	}


	public String getMusculo() {
		return musculo;
	}


	@Override
	public String toString() {
		return "Ejercicio [nombre=" + nombre + ", musculo=" + musculo + "]";
	}
}
	
